#######################################################################
# Copyright (C) 2021  Qian Feng

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Usuage instruction
# This code to generate a list of recombinants according to proposed novel algorithm from mosaic representation results. 
# Note that this code use all triples in jump # chunks(ont only jump once and twice chunks). 
# Input are three files, 
## The first one is partial alignment from mosaic, eg.its name is ***_align.txt; 
## Second file is the original .fasta file
## Third file is the output csv file showing recombinants, its name is ***.csv
# This is used in Python >= 3.5  
# Usage example: python /Users/fengqian/Desktop/replicate_76/codes/integrated_rec_det.py /Users/fengqian/Desktop/replicate_76/simulated_seqs_recombined_align.txt /Users/fengqian/Desktop/replicate_76/integrated_rec_det_results.csv
#######################################################################



from collections import defaultdict
from collections import Counter
from Bio import AlignIO
from Bio import SeqIO
from scipy import stats
import numpy as np
import pandas as pd
import glob
import random
import os
import sys
import csv


input=sys.argv[1];input_fasta=sys.argv[2]
dir=os.getcwd();dir=dir+"/"
output=sys.argv[3]###csv file which is used for store the recombinant in each run

with open(input, 'r') as infile:
    unique_line_index = [];Par_line_index = 0;Chunk_count = 0
    for i, line in enumerate(infile.readlines()):
        line = line.strip().split()
        if "Parameters" in line:#extract line index for lines that contain nothing
            Par_line_index = i
        elif "Target:" in line:
            unique_line_index.append(i)
            Chunk_count = Chunk_count +1
    startline = [m+1 for m in unique_line_index]
    endline = [m-3 for m in unique_line_index if m != unique_line_index[0]]+[Par_line_index-2]
mosaic_output_dbcount=[endline[m]-startline[m]-1 for m in range(Chunk_count)]


### Step5: let's do concatenate for final algorithm
path = dir+"complement_chunks";os.makedirs(path)
for i in range(Chunk_count):
    for k in range(mosaic_output_dbcount[i]-1):
        filename1 = "temp/chunk_"+str(i)+"/s"+str((k+1))+"_mafft_down.fasta"
        filename2 = "temp/chunk_"+str(i)+"/s"+str((k+2))+"_mafft_up.fasta"        
        if os.path.isfile(filename1) and os.path.isfile(filename2): 
            records_bkp = list(SeqIO.parse(filename1, "fasta"))
            bkp=len(str(records_bkp[1].seq))
            concat_file = {}
            temp_file1 = SeqIO.to_dict(SeqIO.parse(filename1, "fasta"))
            for b,v in temp_file1.items():
                concat_file[b]=str(v.seq)
            temp_file2 = SeqIO.to_dict(SeqIO.parse(filename2, "fasta"))
            for p,q in temp_file2.items():
                concat_file[p]=concat_file[p]+str(q.seq)
                with open(dir+"complement_chunks/chunk"+str(i)+"_s"+str((k+1))+str((k+2))+"_"+str(bkp)+".fasta","a+") as outfile:
                    outfile.write(">"+p+"\n"+concat_file[p]+"\n")




# section3: algorithm_rec_detection_all_real.py
#### Step6: This function is used for returning the recombinant sequence by new method
def hamming_distance(seq1, seq2):
    result = sum(b1 != b2 for b1, b2 in zip(seq1, seq2))/len(seq1)
    return result

def main_new(fastafile,bkp):
    distance_name=["ab","ac","bc"];
    temp = SeqIO.to_dict(SeqIO.parse(fastafile, "fasta"))    
    seq_name = [*temp]
    ID_seq = list(SeqIO.parse(fastafile, "fasta"))    
    temp1 = hamming_distance(str(ID_seq[0].seq)[:bkp],str(ID_seq[1].seq)[:bkp])
    temp2 = hamming_distance(str(ID_seq[0].seq)[:bkp],str(ID_seq[2].seq)[:bkp])
    temp3 = hamming_distance(str(ID_seq[1].seq)[:bkp],str(ID_seq[2].seq)[:bkp])
    temp4 = hamming_distance(str(ID_seq[0].seq)[bkp:],str(ID_seq[1].seq)[bkp:])
    temp5 = hamming_distance(str(ID_seq[0].seq)[bkp:],str(ID_seq[2].seq)[bkp:])
    temp6 = hamming_distance(str(ID_seq[1].seq)[bkp:],str(ID_seq[2].seq)[bkp:])       
    distance=[temp1,temp2,temp3,temp4,temp5,temp6];
    compare_distance=[abs(distance[0]-distance[3]),abs(distance[1]-distance[4]),abs(distance[2]-distance[5])]##in order of ab,ac,bc
    temp7 = distance_name[compare_distance.index(min(compare_distance))]
    string = "abc";string = string.replace(temp7[0],"");string = string.replace(temp7[1],"")
    rec=seq_name["abc".index(string)]   
    return rec






for fasta_file in glob.glob(dir+"complement_chunks/*.fasta"):
    bkp=int(fasta_file.split(".fasta")[0].split("_")[-1])
    #chunk=fasta_file.split("/chunk")[1].split("_")[0]
    initial= main_new(fasta_file,bkp)
    #print initial
    mapping_dict={};seq_name=[] 
    pvalue=0;permutation=100;
    test = SeqIO.to_dict(SeqIO.parse(fasta_file, "fasta"))
    seq_name = [*test]
    for k,v in test.items():
        mapping_dict[k]=str(v.seq)
    full_alignment_length=len(mapping_dict[k])
    for m in range(permutation):
        index_1 = np.random.choice(bkp, bkp, replace=True);shuffled_sequences_1=[]
        for n in [mapping_dict[seq_name[0]][0:bkp],mapping_dict[seq_name[1]][0:bkp],mapping_dict[seq_name[2]][0:bkp]]:
            temp_list_1="";
            for j in index_1:
                temp_list_1 = temp_list_1+ n[j];
            shuffled_sequences_1.append(temp_list_1)
        s2_length= full_alignment_length-bkp
        index_2 = np.random.choice(s2_length, s2_length, replace=True);shuffled_sequences_2=[]
        for n in [mapping_dict[seq_name[0]][bkp:],mapping_dict[seq_name[1]][bkp:],mapping_dict[seq_name[2]][bkp:]]:
            temp_list_2="";
            for j in index_2:
                temp_list_2 = temp_list_2+ n[j];
            shuffled_sequences_2.append(temp_list_2)
        shuffled_sequences=[x+y for x,y in zip(shuffled_sequences_1, shuffled_sequences_2)]
        with open(dir+"temp/shuffled_sequence"+str(m)+".fasta", 'w') as outfile:
            outfile.write(">"+seq_name[0]+"\n"+shuffled_sequences[0]+"\n"+">"+seq_name[1]+"\n"+shuffled_sequences[1]+"\n"+">"+seq_name[2]+"\n"+shuffled_sequences[2]+"\n") 
        if main_new(dir+"temp/shuffled_sequence"+str(m)+".fasta",bkp)==initial:
            pvalue+=1/permutation
        os.remove(dir+"temp/shuffled_sequence"+str(m)+".fasta")
    result=[seq_name[0],seq_name[1],seq_name[2],initial,"{:.2f}".format(pvalue)]#headers=["target","db1","db2","rec","sv"]
    with open(output, 'a+') as outfile:
        outfile.write(",".join([str(l) for l in result]) + "\n")


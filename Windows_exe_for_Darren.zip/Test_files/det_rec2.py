#######################################################################
# Copyright (C) 2021  Qian Feng

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Usage instruction
# This code to run mafft to get the aligned triplets from mosaic output
# Input argument is only one file, the partial alignment from mosaic, eg.its name is ***_align.txt; 
# This is used in Python >= 3.5  
# Usage example: python /Users/fengqian/Desktop/codes/det_rec2.py /Users/fengqian/Desktop/simulated_seqs_recombined_align.txt
#######################################################################

import glob
import os
import sys



input=sys.argv[1];#the output_align.txt from running mosaic
dir=os.getcwd();dir=dir+"/"



with open(input, 'r') as infile:
    unique_line_index = [];Par_line_index = 0;Chunk_count = 0
    for i, line in enumerate(infile.readlines()):
        line = line.strip().split()
        if "Parameters" in line:
            Par_line_index = i
        elif "Target:" in line:
            unique_line_index.append(i)
            Chunk_count = Chunk_count +1
    startline = [m+1 for m in unique_line_index]
    endline = [m-3 for m in unique_line_index if m != unique_line_index[0]]+[Par_line_index-2]
mosaic_output_dbcount=[endline[m]-startline[m]-1 for m in range(Chunk_count)]




for i in range(Chunk_count):
    for k in range(mosaic_output_dbcount[i]):
        cmd="mafft --anysymbol --add "+"temp/chunk_"+str(i)+"/s"+str((k+1))+"/add_down.fasta"+" --keeplength --reorder "+"temp/chunk_"+str(i)+"/s"+str((k+1))+"/original.fasta"+" > "+"temp/chunk_"+str(i)+"/s"+str((k+1))+"_mafft_down.fasta"
        os.system(cmd)        
        cmd="mafft --anysymbol --add "+"temp/chunk_"+str(i)+"/s"+str((k+1))+"/add_up.fasta"+" --keeplength --reorder "+"temp/chunk_"+str(i)+"/s"+str((k+1))+"/original.fasta"+" > "+"temp/chunk_"+str(i)+"/s"+str((k+1))+"_mafft_up.fasta"
        os.system(cmd)
        
